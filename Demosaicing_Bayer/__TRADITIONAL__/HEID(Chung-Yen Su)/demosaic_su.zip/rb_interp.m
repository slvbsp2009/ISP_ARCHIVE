% interpolate R and B at G using color correlation

function [r,b]=rb_interp(r,g,b)

[M,N]=size(g);
r0=r(1:2:M,2:2:N);
b0=b(2:2:M,1:2:N);
g0=g(1:2:M,1:2:N);
g1=g(2:2:M,2:2:N);

% interpolate G-R channel at G
Kr0=g(1:2:M,2:2:N)-r0;
Kr(1:2:M,1:2:N)=(Kr0+ishift1(Kr0))/2;
Kr(2:2:M,2:2:N)=(Kr0+shift1(Kr0')')/2;

% interpolate R channel at G
r(1:2:M,1:2:N)=g0-Kr(1:2:M,1:2:N);
r(2:2:M,2:2:N)=g1-Kr(2:2:M,2:2:N);

% interpolate G-B channel at G
Kb0=g(2:2:M,1:2:N)-b0;
Kb(1:2:M,1:2:N)=(Kb0+ishift1(Kb0')')/2;
Kb(2:2:M,2:2:N)=(Kb0+shift1(Kb0))/2;

% interpolate B channel at G
b(1:2:M,1:2:N)=g0-Kb(1:2:M,1:2:N);
b(2:2:M,2:2:N)=g1-Kb(2:2:M,2:2:N);

% interpolate R channel at B
Kr0=g0-r(1:2:M,1:2:N);
Kr1=g1-r(2:2:M,2:2:N);
Kr=(Kr0+shift(Kr0')'+Kr1+ishift(Kr1))/4;
r(2:2:M,1:2:N)=g(2:2:M,1:2:N)-Kr;

% interpolate B channel at R
Kb0=g0-b(1:2:M,1:2:N);
Kb1=g1-b(2:2:M,2:2:N);
Kb=(Kb0+shift(Kb0)+Kb1+ishift(Kb1')')/4;
b(1:2:M,2:2:N)=g(1:2:M,2:2:N)-Kb;





