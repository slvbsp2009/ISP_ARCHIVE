% z

function y=shift(x)

[M,N]=size(x);
tmp(:,1:N-1)=x(:,2:N);
tmp(:,N)=x(:,1);
y=tmp;