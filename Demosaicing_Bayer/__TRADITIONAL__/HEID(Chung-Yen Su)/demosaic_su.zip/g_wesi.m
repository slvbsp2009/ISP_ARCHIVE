% demosaicing algorithm using weighted edge sensitive interpolation
% input: bayer color filter array
% G R G R 
% B G B G
% G R G R
% B G B G

function [R,G,B]=g_wesi(g0,g1,r0,b0,w1)

[m,n]=size(g0);
M=m*2;N=n*2;
R=zeros(M,N); B=zeros(M,N); 
R(1:2:M,2:2:N)=r0;
B(2:2:M,1:2:N)=b0;
G(1:2:M,1:2:N)=g0;
G(2:2:M,2:2:N)=g1;

% bounary interpolation
G(2,3:2:N-1)=(g0(1,2:n)+g0(2,2:n)+g1(1,1:n-1)+g1(1,2:n))/4;
G(3:2:M-1,2)=(g0(2:m,1)+g0(2:m,2)+g1(1:m-1,1)+g1(2:m,1))/4;
G(M-1,2:2:N-2)=(g0(m,1:n-1)+g0(m,2:n)+g1(m-1,1:n-1)+g1(m,1:n-1))/4;
G(2:2:M-2,N-1)=(g0(1:m-1,n)+g0(2:m,n)+g1(1:m-1,n-1)+g1(1:m-1,n))/4;
G(1,2:2:N)=(g0(1,:)+shift1(g0(1,:)))/2;
G(2:2:M,1)=(g0(:,1)+shift1(g0(:,1)')')/2;
G(M,1:2:N)=(g1(m,:)+ishift1(g1(m,:)))/2;
G(1:2:M,N)=(g1(:,n)+ishift1(g1(:,n)')')/2;
G(1,N)=(g0(1,n)+g1(1,n))/2;
G(M,1)=(g0(m,1)+g1(m,1))/2;

% G channel is sampled and interpolated below 
w2=1-w1;
Gdu = G;       
for j=4:2:M-2, % Interpolate G over B samples (excluding borders)
   for i=3:2:N-3,
      deltaH = abs( Gdu(j,i-1)-Gdu(j,i+1) ) + abs( 2*B(j,i)-B(j,i-2)-B(j,i+2) );
	  deltaV = abs( Gdu(j-1,i)-Gdu(j+1,i) ) + abs( 2*B(j,i)-B(j-2,i)-B(j+2,i) );
      if deltaV>deltaH,
         Ih=( Gdu(j,i-1)+Gdu(j,i+1) )/2 + ( 2*B(j,i)-B(j,i-2)-B(j,i+2) )/4;
         Il=( Gdu(j-1,i)+Gdu(j+1,i) )/2 + ( 2*B(j,i)-B(j-2,i)-B(j+2,i) )/4;
         Gdu(j,i) = w1*Ih + w2*Il;
      elseif deltaH>deltaV,
         Ih=( Gdu(j-1,i)+Gdu(j+1,i) )/2 + ( 2*B(j,i)-B(j-2,i)-B(j+2,i) )/4;
         Il=( Gdu(j,i-1)+Gdu(j,i+1) )/2 + ( 2*B(j,i)-B(j,i-2)-B(j,i+2) )/4;
         Gdu(j,i) = w1*Ih + w2*Il;
      else
         Gdu(j,i) = (Gdu(j,i-1)+Gdu(j,i+1)+Gdu(j-1,i)+Gdu(j+1,i))/4 ...
             + ( 2*B(j,i)-B(j,i-2)-B(j,i+2) + 2*B(j,i)-B(j-2,i)-B(j+2,i))/8;
      end;
   end;
end;

for j=3:2:M-3, % Interpolate G over R samples (excluding borders)
   for i=4:2:N-2,
      deltaH = abs( Gdu(j,i-1)-Gdu(j,i+1) ) + abs( 2*R(j,i)-R(j,i-2)-R(j,i+2) );
	  deltaV = abs( Gdu(j-1,i)-Gdu(j+1,i) ) + abs( 2*R(j,i)-R(j-2,i)-R(j+2,i) );
      if deltaV>deltaH,
         Ih=( Gdu(j,i-1)+Gdu(j,i+1) )/2 + ( 2*R(j,i)-R(j,i-2)-R(j,i+2) )/4;
         Il=( Gdu(j-1,i)+Gdu(j+1,i) )/2 + ( 2*R(j,i)-R(j-2,i)-R(j+2,i) )/4;
         Gdu(j,i) = w1*Ih + w2*Il;
      elseif deltaH>deltaV,
         Ih=( Gdu(j-1,i)+Gdu(j+1,i) )/2 + ( 2*R(j,i)-R(j-2,i)-R(j+2,i) )/4;
         Il=( Gdu(j,i-1)+Gdu(j,i+1) )/2 + ( 2*R(j,i)-R(j,i-2)-R(j,i+2) )/4;
         Gdu(j,i) = w1*Ih + w2*Il;
      else
         Gdu(j,i) = (Gdu(j,i-1)+Gdu(j,i+1)+Gdu(j-1,i)+Gdu(j+1,i))/4 ...
              + ( 2*R(j,i)-R(j,i-2)-R(j,i+2) + 2*R(j,i)-R(j-2,i)-R(j+2,i))/8;
      end;
   end;
end;
G=Gdu;









