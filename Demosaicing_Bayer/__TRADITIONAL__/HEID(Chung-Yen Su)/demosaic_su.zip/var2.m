function v=var2(x)

[M,N]=size(x);
if (M*N)>0,
  m=mean2(x);
  e=x-m;
  v=sum(sum(e.*e))/(M*N);
else
  v=1000000;
end