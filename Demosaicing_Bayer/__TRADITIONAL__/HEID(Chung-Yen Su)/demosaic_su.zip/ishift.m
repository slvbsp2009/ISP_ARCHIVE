% z^{-1}

function y=ishift(x)
[M,N]=size(x);
tmp(:,2:N)=x(:,1:N-1);
tmp(:,1)=x(:,N);
y=tmp;