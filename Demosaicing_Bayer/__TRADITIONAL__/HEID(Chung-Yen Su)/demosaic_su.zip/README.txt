
This package contains MATLAB source code of our demosaicing algorithm presented in the paper,

C.-Y. Su, "Effective Iterative Demosaicing Using Weighted Edge and Color Difference Interpolations," submitted to IEEE Trans. Consumer Electronics., March 2006.

The following benchmeark algorithms for comparison can be downloaded from Dr. Li's website at http://www.csee.wvu.edu/~xinl/demo/demosaic.html.
[1] W. Lu and Y.-P. Tan, ��Color filter array demosaicing: New method and performance measures,�� IEEE Trans. Image Process., vol. 12, no. 10, pp. 1194-1210, Oct. 2003.
[2] X. Li, ��Demosaicing by successive approximation,�� IEEE Trans. Image Process., vol. 14, no. 3, pp. 370-379, March 2005.

To test our program, simply type the following command under MATLAB

> run_cfa_su('img',1,12); % test our algorithm for images 1 to 12

A mse_result.txt file listing the experimental results is included. If you have any question regarding the our work, please contact Chung-Yen Su at scy@ntnu.edu.tw
                                                                                 