% interpolate B at G and R using color correlation

function b=b_interp(b,g)

[M,N]=size(g);
b0=b(2:2:M,1:2:N);
g0=g(1:2:M,1:2:N);
g1=g(2:2:M,2:2:N);

% interpolate G-B channel at G
Kb0=g(2:2:M,1:2:N)-b0;
Kb(1:2:M,1:2:N)=(Kb0+ishift1(Kb0')')/2;
Kb(2:2:M,2:2:N)=(Kb0+shift1(Kb0))/2;

% interpolate B channel at G
b(1:2:M,1:2:N)=g0-Kb(1:2:M,1:2:N);
b(2:2:M,2:2:N)=g1-Kb(2:2:M,2:2:N);

% interpolate B channel at R
Kb0=g0-b(1:2:M,1:2:N);
Kb1=g1-b(2:2:M,2:2:N);
Kb=(Kb0+shift(Kb0)+Kb1+ishift(Kb1')')/4;
b(1:2:M,2:2:N)=g(1:2:M,2:2:N)-Kb;





