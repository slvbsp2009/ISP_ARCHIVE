% batch program to run our CFA demosaicing algorithm
% this file is modified from Dr. Li's source code
% at http://www.csee.wvu.edu/~xinl/demo/demosaic.html.

function run_cfa_su(name,start,finish)

% loop over N test images
for i=start:finish
  i
  if i>=10 
        i1=floor(i/10);i2=i-i1*10;
        filename=strcat(name,char(i1+48),char(i2+48));
  else
        filename=strcat(name,char(i+48));
  end
  iname=strcat(filename,'.bmp');
  oname=strcat(filename,'_wesi.bmp');
  x=double(imread(iname));
  r=x(:,:,1);g=x(:,:,2);b=x(:,:,3);
  [M,N,K]=size(x);
  y=zeros(M,N,K);
% change demosaicing technique here
  step=1;
  for m=1:step
    for n=1:step
        I=(m-1)*M/step+1:m*M/step;
        J=(n-1)*N/step+1:n*N/step;
        y(I,J,:)=CFA_wesi(x(I,J,:),10); 
    end
  end
  imwrite(uint8(y),oname);
end