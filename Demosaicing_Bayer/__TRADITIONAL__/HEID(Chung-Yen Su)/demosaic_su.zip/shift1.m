% z

function y=shift1(x)

[M,N]=size(x);
tmp(:,1:N-1)=x(:,2:N);
tmp(:,N)=tmp(:,N-1);
y=tmp;