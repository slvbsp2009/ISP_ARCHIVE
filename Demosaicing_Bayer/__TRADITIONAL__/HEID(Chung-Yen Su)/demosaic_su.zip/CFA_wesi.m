% CFA interpolation using weighted edge sensitive interpolation
% this file is modified from Dr. Li's source code
% at http://www.csee.wvu.edu/~xinl/demo/demosaic.html.
% G R G R 
% B G B G
% G R G R
% B G B G

function [y,mse,v]=CFA_wesi(x,iter)

r=x(:,:,1);g=x(:,:,2);b=x(:,:,3);
% down-sampling to obtain CFA data
[g0,g1,r0,b0]=cfa(r,g,b);

% initialization stage
w1=0.87;
[R,G,B]=g_wesi(g0,g1,r0,b0,w1); % g: weighted edge sensitive interpolation
% refinement stage
[R1,B1]=rb_interp(R,G,B);
G1=g_interp(R1,G,B1);
% iteration stage
var_r=var2(R-R1); var_b=var2(B-B1); var_g=var2(G-G1);
iter_r=1; iter_b=1; iter_g=1;
for i=1:iter
    all_var_less_1=1;
    if var_r>1,
      R=r_interp(R1,G1);
      iter_r=iter_r+1;
      var_r=var2(R-R1); 
      R1=R; 
      all_var_less_1=0;
    end
    if var_b>1,
      B=b_interp(B1,G1);
      iter_b=iter_b+1;
      var_b=var2(B-B1);
      B1=B;
      all_var_less_1=0;
    end
    if var_g>1,
      G=g_interp(R1,G1,B1);
      iter_g=iter_g+1;
      var_g=var2(G-G1);
      G1=G;
      all_var_less_1=0;
    end
    if all_var_less_1>0,
        break;
    end    
end    

R=min(R1,255);R=max(R,0);
G=min(G1,255);G=max(G,0);
B=min(B1,255);B=max(B,0);
mse_t=[var2(R-r),var2(G-g),var2(B-b)]
%PSNR_t=[PSNR(R,r),PSNR(G,g),PSNR(B,b)]
%iter_r;
%iter_b;
%iter_g;
y(:,:,1)=R;y(:,:,2)=G;y(:,:,3)=B;