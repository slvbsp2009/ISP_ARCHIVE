% z^{-1}

function y=ishift1(x)
[M,N]=size(x);
tmp(:,2:N)=x(:,1:N-1);
tmp(:,1)=tmp(:,2);
y=tmp;