% interpolate R at G and B using color correlation

function r=r_interp(r,g)

[M,N]=size(g);
r0=r(1:2:M,2:2:N);
g0=g(1:2:M,1:2:N);
g1=g(2:2:M,2:2:N);

% interpolate G-R channel at G
Kr0=g(1:2:M,2:2:N)-r0;
Kr(1:2:M,1:2:N)=(Kr0+ishift1(Kr0))/2;
Kr(2:2:M,2:2:N)=(Kr0+shift1(Kr0')')/2;

% interpolate R channel at G
r(1:2:M,1:2:N)=g0-Kr(1:2:M,1:2:N);
r(2:2:M,2:2:N)=g1-Kr(2:2:M,2:2:N);

% interpolate R channel at B
Kr0=g0-r(1:2:M,1:2:N);
Kr1=g1-r(2:2:M,2:2:N);
Kr=(Kr0+shift(Kr0')'+Kr1+ishift(Kr1))/4;
r(2:2:M,1:2:N)=g(2:2:M,1:2:N)-Kr;







