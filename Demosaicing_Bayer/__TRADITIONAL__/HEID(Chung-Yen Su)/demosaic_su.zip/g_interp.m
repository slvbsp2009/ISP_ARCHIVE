%interpolate G at R and B using CC

function g=g_interp(r,g,b)

[M,N]=size(g);
r0=r(1:2:M,2:2:N);
b0=b(2:2:M,1:2:N);

Kr0=g(1:2:M,1:2:N)-r(1:2:M,1:2:N);
Kb0=g(1:2:M,1:2:N)-b(1:2:M,1:2:N);
Kr1=g(2:2:M,2:2:N)-r(2:2:M,2:2:N);
Kb1=g(2:2:M,2:2:N)-b(2:2:M,2:2:N);

Kr(1:2:M,2:2:N)=(Kr0+shift1(Kr0)+Kr1+ishift1(Kr1')')/4;
Kb(2:2:M,1:2:N)=(Kb0+shift1(Kb0')'+Kb1+ishift1(Kb1))/4;

g(1:2:M,2:2:N)=r0+Kr(1:2:M,2:2:N);
g(2:2:M,1:2:N)=b0+Kb(2:2:M,1:2:N);

      

