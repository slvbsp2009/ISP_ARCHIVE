function p=PSNR(x,y)

e=x-y;
[M,N]=size(e);
mse=sum(sum(e.*e))/(M*N);
if mse>0
    p=10*log(255*255/mse)/log(10);
else
    p=99.99;
end