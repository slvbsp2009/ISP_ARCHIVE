
Implementation of the algorithm presented in:

Color plane interpolation using alternating projections 
Gunturk, B.K.; Altunbasak, Y.; Mersereau, R.M. 
Image Processing, IEEE Transactions on , Volume: 11 Issue: 9 , Sept 2002 
Page(s): 997-1013


TO TEST THE ALGORITHM RUN TEST.M IN MATLAB. 
PLEASE EMAIL ME FOR QUESTIONS OR COMMENTS.
YOU CAN USE/MODIFY THE CODE FREELY. 
PLEASE ACKNOWLEDGE IN YOUR PUBLICATIONS. 
   

Bahadir K. Gunturk
Department of Electrical and Computer Engineering
Louisiana State University
Email: bahadir@ece.lsu.edu
